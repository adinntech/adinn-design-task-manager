-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: adinn_design_task_manager
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `design_task_eod_records`
--

DROP TABLE IF EXISTS `design_task_eod_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `design_task_eod_records` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `design_task_id` bigint unsigned NOT NULL,
  `designer_id` bigint unsigned NOT NULL,
  `update_type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'progress',
  `completed_count` int unsigned NOT NULL,
  `total_creatives_snapshot` int unsigned NOT NULL,
  `cumulative_completed` int unsigned NOT NULL,
  `remaining_creatives` int unsigned NOT NULL,
  `rework_count_snapshot` int unsigned DEFAULT NULL,
  `attachment_disk` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment_path` text COLLATE utf8mb4_unicode_ci,
  `attachment_original_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `submitted_at` timestamp NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `design_task_eod_records_design_task_id_submitted_at_index` (`design_task_id`,`submitted_at`),
  KEY `design_task_eod_records_designer_id_submitted_at_index` (`designer_id`,`submitted_at`),
  CONSTRAINT `design_task_eod_records_design_task_id_foreign` FOREIGN KEY (`design_task_id`) REFERENCES `design_tasks` (`id`) ON DELETE CASCADE,
  CONSTRAINT `design_task_eod_records_designer_id_foreign` FOREIGN KEY (`designer_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `design_task_eod_records`
--

LOCK TABLES `design_task_eod_records` WRITE;
/*!40000 ALTER TABLE `design_task_eod_records` DISABLE KEYS */;
INSERT INTO `design_task_eod_records` VALUES (1,16,6,'progress',1,4,1,3,NULL,NULL,NULL,NULL,'2026-08-10 06:41:07','2026-08-10 06:41:07','2026-08-10 06:41:07'),(2,10,6,'progress',2,3,2,1,NULL,NULL,NULL,NULL,'2026-08-11 05:57:00','2026-08-11 05:57:00','2026-08-11 05:57:00'),(3,10,6,'progress',1,3,3,0,NULL,NULL,NULL,NULL,'2026-08-11 05:57:27','2026-08-11 05:57:27','2026-08-11 05:57:27'),(4,21,6,'progress',3,8,3,5,NULL,'spaces','design_task_manager/2026/outdoor/DT-2026-00021_task-1782026/mockup-requirements/task-updation/DT-2026-00021__task-updation__20260817-110225-736.zip','Reference For UI (2).zip','2026-08-17 05:32:26','2026-08-17 05:32:26','2026-08-17 05:32:26'),(5,20,6,'progress',3,8,3,5,NULL,'spaces','design_task_manager/2026/fixtures/DT-2026-00020_task-3/design-with-creative/task-updation/DT-2026-00020__task-updation__20260817-110624-375.zip','Reference For UI (2).zip','2026-08-17 05:36:25','2026-08-17 05:36:25','2026-08-17 05:36:25'),(6,20,6,'progress',3,8,6,2,NULL,'spaces','design_task_manager/2026/fixtures/DT-2026-00020_task-3/design-with-creative/task-updation/DT-2026-00020__task-updation__20260817-110728-380.zip','Reference For UI (2).zip','2026-08-17 05:37:29','2026-08-17 05:37:29','2026-08-17 05:37:29'),(7,20,6,'progress',2,8,8,0,NULL,'spaces','design_task_manager/2026/fixtures/DT-2026-00020_task-3/design-with-creative/task-updation/DT-2026-00020__task-updation__20260817-110809-016.zip','Reference For UI (2).zip','2026-08-17 05:38:10','2026-08-17 05:38:10','2026-08-17 05:38:10');
/*!40000 ALTER TABLE `design_task_eod_records` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-17 11:29:45
