-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: adinn_design_task_manager
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `design_task_edit_histories`
--

DROP TABLE IF EXISTS `design_task_edit_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `design_task_edit_histories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `design_task_id` bigint unsigned NOT NULL,
  `edited_by` bigint unsigned NOT NULL,
  `edit_batch_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_name` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `old_value` text COLLATE utf8mb4_unicode_ci,
  `new_value` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `design_task_edit_histories_edited_by_foreign` (`edited_by`),
  KEY `design_task_edit_histories_design_task_id_created_at_index` (`design_task_id`,`created_at`),
  KEY `design_task_edit_histories_edit_batch_id_index` (`edit_batch_id`),
  CONSTRAINT `design_task_edit_histories_design_task_id_foreign` FOREIGN KEY (`design_task_id`) REFERENCES `design_tasks` (`id`) ON DELETE CASCADE,
  CONSTRAINT `design_task_edit_histories_edited_by_foreign` FOREIGN KEY (`edited_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `design_task_edit_histories`
--

LOCK TABLES `design_task_edit_histories` WRITE;
/*!40000 ALTER TABLE `design_task_edit_histories` DISABLE KEYS */;
INSERT INTO `design_task_edit_histories` VALUES (1,15,1,'083ef817-6398-45bf-85e9-931fa64a2a08','Due Date','10 Aug 2026, 03:49 PM','12 Aug 2026, 03:49 PM','2026-08-11 06:41:57','2026-08-11 06:41:57'),(2,15,1,'083ef817-6398-45bf-85e9-931fa64a2a08','Total Creatives','10','20','2026-08-11 06:41:57','2026-08-11 06:41:57'),(3,21,1,'6bf905eb-e237-4feb-be84-30248e7fcbbb','Contact Person','Lakshman','Lakshman K','2026-08-17 05:25:49','2026-08-17 05:25:49'),(4,21,1,'6bf905eb-e237-4feb-be84-30248e7fcbbb','Due Date','21 Aug 2026, 10:40 AM','22 Aug 2026, 11:40 AM','2026-08-17 05:25:49','2026-08-17 05:25:49'),(5,21,1,'6bf905eb-e237-4feb-be84-30248e7fcbbb','Total Creatives','4','5','2026-08-17 05:25:49','2026-08-17 05:25:49'),(6,21,1,'8ddf2998-ed0d-4fbd-8cb6-8ce79d0345c0','Total Creatives','5','8','2026-08-17 05:27:50','2026-08-17 05:27:50'),(7,20,1,'94d62366-0ef4-4c6b-8fd7-f4f6a313cc9b','Total Creatives','1','8','2026-08-17 05:34:23','2026-08-17 05:34:23'),(8,23,1,'ea3d087b-1ee2-4a41-a10c-61039861a930','Assigned Designer','Test 2','Demo Designer','2026-08-18 04:28:33','2026-08-18 04:28:33'),(9,22,1,'7a47a88a-a34a-40d4-9bd8-7e03c71d2b4b','Total Creatives','5','25','2026-08-18 05:18:40','2026-08-18 05:18:40');
/*!40000 ALTER TABLE `design_task_edit_histories` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-19 11:59:56
