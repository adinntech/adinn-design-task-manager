-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: adinn_design_task_manager
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `design_task_requests`
--

DROP TABLE IF EXISTS `design_task_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `design_task_requests` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `design_task_id` bigint unsigned NOT NULL,
  `request_type` enum('decline','split','swap') COLLATE utf8mb4_unicode_ci NOT NULL,
  `requested_by` bigint unsigned NOT NULL,
  `designer_head_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `designer_head_action_by` bigint unsigned DEFAULT NULL,
  `designer_head_action_at` timestamp NULL DEFAULT NULL,
  `admin_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `admin_action_by` bigint unsigned DEFAULT NULL,
  `admin_action_at` timestamp NULL DEFAULT NULL,
  `overall_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending_designer_head',
  `reason` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `decision_reason` text COLLATE utf8mb4_unicode_ci,
  `target_designer_id` bigint unsigned DEFAULT NULL,
  `approved_designer_id` bigint unsigned DEFAULT NULL,
  `split_details` json DEFAULT NULL,
  `attachments` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `design_task_requests_design_task_id_foreign` (`design_task_id`),
  KEY `design_task_requests_requested_by_foreign` (`requested_by`),
  KEY `design_task_requests_designer_head_action_by_foreign` (`designer_head_action_by`),
  KEY `design_task_requests_admin_action_by_foreign` (`admin_action_by`),
  KEY `design_task_requests_target_designer_id_foreign` (`target_designer_id`),
  KEY `design_task_requests_approved_designer_id_foreign` (`approved_designer_id`),
  CONSTRAINT `design_task_requests_admin_action_by_foreign` FOREIGN KEY (`admin_action_by`) REFERENCES `users` (`id`),
  CONSTRAINT `design_task_requests_approved_designer_id_foreign` FOREIGN KEY (`approved_designer_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `design_task_requests_design_task_id_foreign` FOREIGN KEY (`design_task_id`) REFERENCES `design_tasks` (`id`) ON DELETE CASCADE,
  CONSTRAINT `design_task_requests_designer_head_action_by_foreign` FOREIGN KEY (`designer_head_action_by`) REFERENCES `users` (`id`),
  CONSTRAINT `design_task_requests_requested_by_foreign` FOREIGN KEY (`requested_by`) REFERENCES `users` (`id`),
  CONSTRAINT `design_task_requests_target_designer_id_foreign` FOREIGN KEY (`target_designer_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `design_task_requests`
--

LOCK TABLES `design_task_requests` WRITE;
/*!40000 ALTER TABLE `design_task_requests` DISABLE KEYS */;
INSERT INTO `design_task_requests` VALUES (1,7,'swap',6,'approved',8,'2026-08-07 11:39:45','pending',NULL,NULL,'approved','testtt',NULL,9,NULL,'{\"notes\": \"\"}',NULL,'2026-08-07 10:51:05','2026-08-07 11:39:45'),(2,7,'split',9,'approved',5,'2026-08-07 12:17:17','pending',NULL,NULL,'approved','test',NULL,9,NULL,'{\"details\": \"test\", \"creative_count\": 10, \"created_task_id\": 8}',NULL,'2026-08-07 11:41:12','2026-08-07 12:17:17'),(3,9,'split',9,'approved',5,'2026-08-08 05:18:30','not_required',NULL,NULL,'approved','split the Task',NULL,6,NULL,'{\"details\": \"split\", \"creative_count\": 3, \"created_task_id\": 10, \"created_task_code\": \"DT-2026-00010\", \"original_remaining_creatives\": 3}',NULL,'2026-08-08 05:18:14','2026-08-08 05:18:30'),(4,11,'split',6,'approved',5,'2026-08-08 06:09:17','not_required',NULL,NULL,'approved','Split',NULL,9,9,'{\"details\": \"Split\", \"creative_count\": 3, \"created_task_id\": 12, \"created_task_code\": \"DT-2026-00012\", \"original_remaining_creatives\": 3}',NULL,'2026-08-08 06:08:50','2026-08-08 06:09:17'),(5,13,'split',6,'approved',5,'2026-08-08 10:10:42','not_required',NULL,NULL,'approved','I cannot finish within deadline',NULL,9,9,'{\"details\": \"kindly check the attached images\", \"creative_count\": 35, \"created_task_id\": 14, \"created_task_code\": \"DT-2026-00014\", \"original_remaining_creatives\": 35}','[\"design_task_manager/2026/outdoor/DT-2026-00013_test-7/mockup-requirements/requests/split/DT-2026-00013__request-split__all-task-conban-view__20260808-152604-771.jpeg\"]','2026-08-08 09:56:05','2026-08-08 10:10:42'),(6,9,'split',9,'rejected',5,'2026-08-08 10:15:42','not_required',NULL,NULL,'rejected','Cannot finish it within time',NULL,6,NULL,'{\"details\": \"I have finished 2\", \"creative_count\": 2}','[\"design_task_manager/2026/outdoor/DT-2026-00009_test-4/mockup-requirements/requests/split/DT-2026-00009__request-split__task-info-task-overview__20260808-154524-115.jpeg\"]','2026-08-08 10:15:24','2026-08-08 10:15:42'),(7,15,'swap',6,'rejected',5,'2026-08-08 10:23:33','not_required',NULL,NULL,'rejected','I want to swap as im occupied with multiple tasks',NULL,3,NULL,'{\"notes\": \"\"}',NULL,'2026-08-08 10:21:59','2026-08-08 10:23:33'),(8,16,'swap',9,'approved',5,'2026-08-08 10:29:29','not_required',NULL,NULL,'approved','Cannot complete it',NULL,6,6,'{\"notes\": \"\"}',NULL,'2026-08-08 10:28:40','2026-08-08 10:29:29'),(9,17,'swap',6,'rejected',5,'2026-08-10 07:04:17','not_required',NULL,NULL,'rejected','I want to swap','i m not willing to approve',9,NULL,'{\"notes\": \"\", \"previous_status\": \"review_analysis\"}',NULL,'2026-08-10 07:03:35','2026-08-10 07:04:17'),(10,17,'swap',6,'rejected',5,'2026-08-10 07:05:22','not_required',NULL,NULL,'rejected','I want to swap','I m not willing to approve',9,NULL,'{\"notes\": \"\", \"previous_status\": \"review_analysis\"}',NULL,'2026-08-10 07:04:59','2026-08-10 07:05:22'),(11,17,'swap',6,'approved',5,'2026-08-10 07:06:08','not_required',NULL,NULL,'approved','I want to swap',NULL,9,9,'{\"notes\": \"\", \"previous_status\": \"review_analysis\"}',NULL,'2026-08-10 07:05:47','2026-08-10 07:06:08'),(12,18,'swap',6,'pending',NULL,NULL,'pending',NULL,NULL,'pending_approval','have many tasks',NULL,9,NULL,'{\"notes\": \"Tasks\", \"previous_status\": \"need_clarification\"}',NULL,'2026-08-14 05:20:27','2026-08-14 05:20:27'),(13,20,'decline',6,'rejected',5,'2026-08-14 07:06:05','not_required',NULL,NULL,'rejected','got more work','bjb',NULL,NULL,NULL,NULL,'2026-08-14 06:59:15','2026-08-14 07:06:05'),(14,20,'decline',6,'pending',NULL,NULL,'pending',NULL,NULL,'pending_approval','nbbklpo',NULL,NULL,NULL,NULL,NULL,'2026-08-14 07:07:28','2026-08-14 07:07:28'),(15,22,'decline',6,'rejected',5,'2026-08-18 04:51:57','not_required',NULL,NULL,'rejected','I cannot finish within the deadline as i have many tasks','all the designers are occupied, ill ask to increase the deadline',NULL,NULL,NULL,'[\"design_task_manager/2026/outdoor/DT-2026-00022_task-5/mockup-requirements/requests/decline/DT-2026-00022__request-decline__designer-head-dashboardmarked__20260818-101935-745.jpeg\"]','2026-08-18 04:49:36','2026-08-18 04:51:57'),(16,24,'swap',6,'rejected',5,'2026-08-19 06:02:37','not_required',NULL,NULL,'rejected','I got multiple Tasks','Sorry I cannot Approve',9,NULL,'{\"notes\": \"\", \"previous_status\": \"need_clarification\"}',NULL,'2026-08-19 06:01:59','2026-08-19 06:02:37'),(17,24,'swap',6,'approved',5,'2026-08-19 06:03:50','not_required',NULL,NULL,'approved','Kindly Swap',NULL,9,9,'{\"notes\": \"\", \"active_task_id\": 25, \"previous_status\": \"need_clarification\", \"active_task_code\": \"DT-2026-00025\", \"previous_designer_id\": 6}',NULL,'2026-08-19 06:03:13','2026-08-19 06:03:50');
/*!40000 ALTER TABLE `design_task_requests` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-19 11:59:57
