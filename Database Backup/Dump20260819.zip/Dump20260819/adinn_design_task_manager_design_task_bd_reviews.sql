-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: adinn_design_task_manager
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `design_task_bd_reviews`
--

DROP TABLE IF EXISTS `design_task_bd_reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `design_task_bd_reviews` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `design_task_id` bigint unsigned NOT NULL,
  `submitted_by` bigint unsigned NOT NULL,
  `action` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number_of_creatives` int unsigned DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `designer_attitude` decimal(2,1) DEFAULT NULL,
  `design_satisfaction` decimal(2,1) DEFAULT NULL,
  `rework_iteration` decimal(2,1) DEFAULT NULL,
  `meeting_deadline` decimal(2,1) DEFAULT NULL,
  `client_satisfaction` decimal(2,1) DEFAULT NULL,
  `overall_rating` decimal(3,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `design_task_bd_reviews_submitted_by_foreign` (`submitted_by`),
  KEY `design_task_bd_reviews_design_task_id_action_index` (`design_task_id`,`action`),
  CONSTRAINT `design_task_bd_reviews_design_task_id_foreign` FOREIGN KEY (`design_task_id`) REFERENCES `design_tasks` (`id`) ON DELETE CASCADE,
  CONSTRAINT `design_task_bd_reviews_submitted_by_foreign` FOREIGN KEY (`submitted_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `design_task_bd_reviews`
--

LOCK TABLES `design_task_bd_reviews` WRITE;
/*!40000 ALTER TABLE `design_task_bd_reviews` DISABLE KEYS */;
INSERT INTO `design_task_bd_reviews` VALUES (1,21,1,'rework',3,'Please the first 3 creative and update it',NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-18 05:29:15','2026-08-18 05:29:15'),(2,23,1,'rework',2,'rework required',NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-18 06:51:38','2026-08-18 06:51:38'),(3,23,1,'completed',3,'Good Work',4.5,5.0,5.0,4.5,5.0,4.80,'2026-08-18 06:55:29','2026-08-18 06:55:29'),(4,20,1,'rework',2,'Please 3rd and 5th creative needs rework',NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-19 04:19:02','2026-08-19 04:19:02');
/*!40000 ALTER TABLE `design_task_bd_reviews` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-19 11:59:57
